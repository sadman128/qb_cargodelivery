# qb_cargodelivery 
	* esx_cargodelivery job converted to QBCore by sadman128

# Original script - [https://github.com/apoiat/ESX_Cargodelivery]

### Requirements
* QBCore Police job
  * to get number of police (can be changed)
* QBCore 
  * absolutely  needed

## Download & Installation

* Drag and drop file.
* Ensure it in server.cfg
* Check congfig file to config it accordingly


### I am very new in this field(still learning). I tried to convert it for my server. It worked for me. let me know if you face any issue, I will to solve it. You can knock me on discod (kenji.xx)